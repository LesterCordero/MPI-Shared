#include <mpi.h> 
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <random>
#include <iomanip>
#include <chrono>
#include <cmath>
#include <algorithm>

using namespace std;

// Constantes de estados globales
#pragma warning(disable:4996)
#define healthy 0
#define infected 1
#define recovered 2
#define death 3

// Esta funci�n solo es para hacer el cout mas bonito al organizar en columnas los n�meros
template <class T>
int numDigits(T number) {
	int digits = 0;
	// Diga de cuantos digitos es un n�mero de base 10
	while (number) {
		number /= 10;
		digits++;
	}
	return digits;
}

// Obtiene el porcentaje de dos n�meros dados
int getPercent(int a, int b) {
	return (a * 100) / b;
}

// Imprime el estado actual en formato de estadistica, basado en los datos
// Osea los promedios, los porcentajes, etc
void printState(stringstream& out, string keyword, int digitosDePersonas, int sum, int total, int prom, int state) {
	out << keyword << ": " << setw(digitosDePersonas) << sum;
	out << " (" << setw(3) << getPercent(sum, total) << "%, " << setw(digitosDePersonas) << prom / state << ")  " << setw(1);
}


// Escribe la estructura de personas de forma rapida
void writeStruct(int* m, int i, int x, int y, int s, int t) {
	m[(4 * i) + 0] = x; // Coord X
	m[(4 * i) + 1] = y; // Coord Y
	m[(4 * i) + 2] = s; // Estado
	m[(4 * i) + 3] = t; // Tiempo enfermo
}

// Convierte rapidamente una estructura de personas infectadas, en una estructura vectorial
void structToVectorialSpaceOfInfected(int* m, int msize, int** dst) {
	int x; // Coordenada x
	int y; // Coordenada y
	int s; // Estado actual
	for (int i = 0; i < msize; i++) {
		x = m[(4 * i) + 0];
		y = m[(4 * i) + 1];
		s = m[(4 * i) + 2];

		// Escribe en la matriz destino correspondiente al estado de infeccion de la persona
		if (s == infected) {
			dst[x][y]++;
		}
	}
}

// Limpia el espacio vectorial completamente
void clearVectorialSpace(int msize, int** dst) {
	for (int x = 0; x < msize; x++) {
		for (int y = 0; y < msize; y++) {
			dst[x][y] = 0;
		}
	}
}

// Funcion de debugging que permite visualizar un espacio vectorial
void printVectorialSpace(int** m, int param_room_size) {
	for (int y = 0; y < param_room_size; y++) {
		for (int x = 0; x < param_room_size; x++) {
			if (m[x][y] == 0) {
				cout << " -";
			}
			else {
				cout << " " << m[x][y];
			}
		}
		cout << endl;
	}
}

void printStructure(int* m, int size) {
	for (int i = 0; i < size; i++) {
		cout << "(" << m[(4 * i) + 0] << "," << m[(4 * i) + 1] << "," << m[(4 * i) + 2] << "," << m[(4 * i) + 3] << ") ";
	}
	cout << endl;
}

// Numero random entre min y max(inclusivo)
int getRandom(int min, int max) {
	return min + rand() % ((max + 1) - min);
}

// Genera una matriz dinamica de 1 dimensi�n
int* new1DArray(int size) {
	int* array1d = new int[size]();
	return array1d;
}

// Destruye una matriz dinamica de 1 dimensi�n
void delete1DArray(int* m) {
	delete[] m;
}

// Genera una matriz dinamica de 2 dimensiones
int** new2DArray(int size) {
	int **array2d = new int*[size];
	for (int i = 0; i < size; ++i) {
		array2d[i] = new int[size]();
	}
	return array2d;
}

// Destruye una matriz dinamica de 2 dimensiones
void delete2DArray(int** m, int size) {
	for (int i = 0; i < size; ++i) {
		delete[] m[i];
	}
	delete[] m;
}

// Comprueba que todos los par�metros sean v�lidos
bool checkParam(char* param[], int paramID) {
	char *validate;
	int num = strtol(param[paramID], &validate, 10);
	if (*validate != '\0') {
		if (num <= 0) {
			return false;
		}
	}
	return true;
}

void printCorrectUsage() {
	cout << "ADVERTENCIA! Usted ha ingresado mal los parametros. La forma correcta es: " << endl << endl;
	cout << "Numero de personas (entero mayor que 0) " << endl;
	cout << "Probabilidad de infectarse (entero entre 0 a 100) " << endl;
	cout << "Probabilidad de recuperarse (entero entre 0 a 100) " << endl;
	cout << "Tiempo de la enfermadad (entero mayor que 0) " << endl;
	cout << "Porcentaje de infeccion inicial (entero entre 0 a 100) " << endl;
	cout << "Dimension del espacio vectorial (entero mayor que 0) " << endl;
}

// M�todo de inicio del programa
int main(int argc, char* argv[]) {

	// Inicializaci�n b�sica de MPI
	int process_ID;
	int process_num;
	MPI_Status mpi_status;

	// Arranque el ambiente y prepara sus dos varialbes iniciales
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &process_ID);
	MPI_Comm_size(MPI_COMM_WORLD, &process_num);

	// Modo de uso obligatorio para los par�metros
	if (argc < 7) {
		if (process_ID == 0) {
			printCorrectUsage();
			cin.ignore();
		}
		MPI_Barrier(MPI_COMM_WORLD);
		MPI_Finalize();
		return -1;

	}

	// Valida todos los par�metros antes de hacer cualquier cosa
	for (int p = 1; p < argc; p++) {
		if (!checkParam(argv, p)) {
			if (process_ID == 0) {
				printCorrectUsage();
				cin.ignore();
			}
			MPI_Barrier(MPI_COMM_WORLD);
			MPI_Finalize();
			return -1;
		}
	}

	// Cargue los datos validados inciales de la simulaci�n
	int param_people = strtol(argv[1], NULL, 10);
	int param_infect_chance = strtol(argv[2], NULL, 10);
	int param_recover_chance = strtol(argv[3], NULL, 10);
	int param_disease_time = strtol(argv[4], NULL, 10);
	int param_infect_start = strtol(argv[5], NULL, 10);
	int param_room_size = strtol(argv[6], NULL, 10);

	// Notificacion de par�metros iniciales
	stringstream out;
	if (process_ID == 0) {
		cout << "Calculando, por favor espere..." << endl;

		out << "[MPI] EL ambiente MPI ha iniciado correctamente." << endl;
		out << "[MPI] Numero de procesos paralelos: " << process_num << endl;

		//Imprima los parametros inciales para el usuario
		out << "[INF] Numero de personas en la civilizacion: " << param_people << endl;
		out << "[INF] Probabilidad de infeccion: " << param_infect_chance << "%" << endl;
		out << "[INF] Probabilidad de recuperacion: " << param_recover_chance << "%" << endl;
		out << "[INF] Duracion de la enfermedad en semanas: " << param_disease_time << endl;
		out << "[INF] Porcentaje de infectados iniciales: " << param_infect_start << "%" << endl;
		out << "[INF] Dimension matricial del espacio vectorial: " << param_room_size << "x" << param_room_size << endl;
	}

	// Cambie la semilla para la lista random
	srand(time(NULL));

	// Solo el proceso maestro maneja los contadores globales
	int global_stats_healthy = 0;
	int global_stats_infected = 0;
	int global_stats_recovered = 0;
	int global_stats_death = 0;

	// Promedios del proceso maestro que cuenta los datos conforme van cambiando
	int global_prom_healthy = 0;
	int global_prom_infected = 0;
	int global_prom_recovered = 0;
	int global_prom_death = 0;

	// Los procesos esclavos, al realizar sus partes, contienen contadores locales que indican los cambios (que sirven para promedios y esas cosas)
	int local_stats[4] = { 0,0,0,0 }; // Y seran enviados por medio de este vector peque�o por MPI (healthyNum, infectedNum, Recovered, Death)

	// Cada persona tiene 4 par�metros (x,y,estado,tiempoEnfermo) y todo los procesos lo tienen
	int people_distribution = (param_people) / process_num; // Distribuye la carga entre los procesos
	int* global_people = new1DArray(param_people * 4);          // Manejara todas las personas
	int* local_people = new1DArray((param_people * 4) / process_num);  // Manejara las personas por proceso (solo una parte)

	// Para hacer el cout mas bonito (y mucho!)
	int digitosDePersonas = numDigits(param_people);

	// Todos los procesos en alg�n momento recrearan el espacio vectorial por lo que reservaremos la memoria
	int** local_room_infected = new2DArray(param_room_size);    // Indica los enfermos en un espacio vectorial local para rapidamente tirar los datos

	// Ahora el hilo maestro va gererar la matriz random de datos de personas y sus valores de contadores
	if (process_ID == 0) {

		// Contadores iniciales (por el momento)
		global_stats_infected = (int)(param_infect_start*param_people) / 100;
		global_stats_healthy = param_people - global_stats_infected;
		global_stats_recovered = 0;
		global_stats_death = 0;

		// Coloca a las personas en posiciones al azar en el universo (como una Struct)
		for (int i = 0; i < param_people; i++) {
			if (i < global_stats_infected) {
				writeStruct(global_people, i, getRandom(0, param_room_size - 1), getRandom(0, param_room_size - 1), infected, 0);
			}
			else {
				writeStruct(global_people, i, getRandom(0, param_room_size - 1), getRandom(0, param_room_size - 1), healthy, 0);
			}
		}

		out << "La simulacion ha comenzado." << endl;
	}

	// Apartir de este momento, arrancamos la simulacion, ya que ya tenemos los datos de par�metros y las personas iniciales y ya vamos a comenzar la comunicaci�n
	// Cronometro sincronizado inicial
	double local_start = MPI_Wtime();

	// Ahora que se genere el estado inicial en el proceso maestro, distribuyalo a TODOS los procesos
	MPI_Bcast(global_people, param_people * 4, MPI_INT, 0, MPI_COMM_WORLD);

	// Indica el estado actual que estamos
	int currentState = 0;

	// Siempre que haya enfermos, siga ejecutando la simulacion (bandera de parada)
	int* shouldBeRunning = new int();
	*shouldBeRunning = 1;

	// Bandera inteligente que desactiva el sistema de contaminacion al NO haber muertos
	int* shouldRemakeTheInfectTable = new int();
	*shouldRemakeTheInfectTable = 1;

	while (*shouldBeRunning == 1) {

		// Cuando cada hilo tiene el estado actual, reconstruya de la lista de personas, el espacio vectorial de enfermos y sanos actual
		if (*shouldRemakeTheInfectTable == 1) {

			// Reinice los espacios vectoriales, OJO, pero solo los espacios vectoriales, no el mensaje de datos de personas
			clearVectorialSpace(param_room_size, local_room_infected);

			// Si hay existen sanos que infectar, debe reconstruir el universo para visualizar enfermos de una pasada
			structToVectorialSpaceOfInfected(global_people, param_people, local_room_infected);
		}

		// Recorra solo una parte de las personas y no todas las personas (eso le toca a los demas procesos)
		int x = 0; // Coordenada x
		int y = 0; // Coordenada Y
		int s = 0; // Estado
		int t = 0; // Tiempo enfermo (si esta en estado enfermo)
		int k = 0; // Iterador para escribir en la matriz que sera enviada

		for (int i = people_distribution * process_ID; i < (people_distribution*process_ID) + people_distribution; i++) {

			x = global_people[(4 * i) + 0];
			y = global_people[(4 * i) + 1];
			s = global_people[(4 * i) + 2];
			t = global_people[(4 * i) + 3];

			// Ejecute el Estado T
			// Haga una accion espec�fica si soy un tipo de persona
			if (s == healthy) {

				// Tire los dados para enfermarme seg�n el n�mero de enfermos en mi celda actual
				for (int w = 0; w < local_room_infected[x][y]; w++) {
					if (getRandom(0, 100) <= param_infect_chance) {
						s = infected;
					}
				}

			}
			else if (s == infected) {
				// Si ya estaba enfermo, entonces espere al final de la enfermedad para ver si me recupero o me muero
				t++;
				if (t >= param_disease_time) {
					local_stats[infected]--;
					if (getRandom(0, 100) <= param_recover_chance) {
						s = recovered;
						local_stats[recovered]++;
					}
					else {
						s = death;
						local_stats[death]++;
					}
				}
			}

			// Ejecute el Estado T + 1
			// Ahora que ya les ejecuto el estado (T), muevalos para que esten listos para el estado (T+1)
			// xx, yy, son los desplazamientos en X y Y
			int xx = 1;
			int yy = 1;
			if (getRandom(0, 100) < 50) { xx = -1; }
			if (getRandom(0, 100) < 50) { yy = -1; }
			x += xx;
			y += yy;
			if (x < 0) { x = 0; }
			if (y < 0) { y = 0; }
			if (x > param_room_size - 1) { x = param_room_size - 1; }
			if (y > param_room_size - 1) { y = param_room_size - 1; }

			// Ahora escriba el resultado en la persona actual de la submatriz "tajadeada"
			local_people[4 * k + 0] = x;
			local_people[4 * k + 1] = y;
			local_people[4 * k + 2] = s;
			local_people[4 * k + 3] = t;

			// Mueva el iterador de persona
			k++;
		}

		// Incrementa el estado actual de T a (T+1)
		currentState++;

		// Asegurese que este proceso ocurra con todos al mismo tiempo, pues estado T+1, depende de T completamente
		MPI_Barrier(MPI_COMM_WORLD);

		// Ahora que ya lleno local_people de los datos nuevos, use all gather para sincronizar todos los hilos
		MPI_Allgather(&local_people[0], (4 * param_people) / process_num, MPI_INT, &global_people[0], (4 * param_people) / process_num, MPI_INT, MPI_COMM_WORLD);

		if (process_ID == 0) {

			global_stats_healthy = 0;
			global_stats_infected = 0;
			global_stats_recovered = 0;
			global_stats_death = 0;

			// Actualize de una pasada, todos los contadores
			for (int count = 0; count < param_people; count++) {
				switch (global_people[(4 * count) + 2]) {
				case healthy: global_stats_healthy++; break;
				case infected: global_stats_infected++; break;
				case recovered: global_stats_recovered++; break;
				case death: global_stats_death++; break;
				}
			}

			// Sume los promedios
			global_prom_healthy += global_stats_healthy;
			global_prom_infected += global_stats_infected;
			global_prom_recovered += global_stats_recovered;
			global_prom_death += global_stats_death;

			// Si ya no hay sanos, desactive la reconstruccion matricial para agilizar los c�lculos, en casos donde el sistema se estabiliza en el m�ximo de enfermos
			if (global_stats_healthy == 0) {
				*shouldRemakeTheInfectTable = 0;
			}

			// Si han ocurrido mas de 500 estados (algo anda mal si esto pasa), o ya no hay infectados, informe que ya vamos a terminar
			if (global_stats_infected <= 0 || currentState > 300) {
				*shouldBeRunning = 0;
			}

			// Ahora imprima el n�mero de personas del estado actual
			out << "Dia " << setw(3) << setfill('0') << currentState << " >> " << setfill(' ');

			// Imprima las estadisticas por tick
			printState(out, "Sanos", digitosDePersonas, global_stats_healthy, param_people, global_prom_healthy, currentState);
			printState(out, "| Enfermos", digitosDePersonas, global_stats_infected, param_people, global_prom_infected, currentState);
			printState(out, "| Recuperados", digitosDePersonas, global_stats_recovered, param_people, global_prom_recovered, currentState);
			printState(out, "| Muertos", digitosDePersonas, global_stats_death, param_people, global_prom_death, currentState);

			out << endl;
		}

		// Enviele a todos los procesos las banderas globales, para que sepan si el sistema de estabilizo, o si el sistema debe seguir simulando
		MPI_Bcast(shouldBeRunning, 1, MPI_INT, 0, MPI_COMM_WORLD);
		MPI_Bcast(shouldRemakeTheInfectTable, 1, MPI_INT, 0, MPI_COMM_WORLD);

	}

	// Cronometro sincronizado final
	double total_elapsed;
	double local_elapsed = MPI_Wtime() - local_start;
	MPI_Reduce(&local_elapsed, &total_elapsed, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

	// Termina los procesos MPI
	if (process_ID == 0) {
		out << "[INF] Tiempo transcurrido en total: " << total_elapsed << endl;
		out << "[INF] Tiempo transcurrido por tick: " << total_elapsed / currentState << endl;
		out << "[MPI] EL ambiente MPI ha terminado correctamente." << endl;

		char fecha_string[25];
		char tiempo_string[25];

		time_t curr_time;
		tm * curr_tm;
		time(&curr_time);
		curr_tm = localtime(&curr_time);

		// Genera la fecha y hora y lo agrega al nombre del archivo de salida
		strftime(fecha_string, 50, "%e.%m.%y_", curr_tm);
		strftime(tiempo_string, 50, "%H.%M.%S", curr_tm);

		// Construya el nombre de archivo
		string nombreArchivo = "Civilizacion_";
		nombreArchivo.append(fecha_string);
		nombreArchivo.append(tiempo_string);
		nombreArchivo = nombreArchivo + ".txt";

		std::ofstream outFile(nombreArchivo);

		// Ahora imprima al archivo y a la salida de consola
		cout << out.str();
		outFile << out.str();

		outFile.close();
	}

	// Destruyra toda la memoria al finalizar el programa
	delete1DArray(global_people);
	delete1DArray(local_people);
	delete2DArray(local_room_infected, param_room_size);
	delete shouldBeRunning;
	delete shouldRemakeTheInfectTable;

	MPI_Barrier(MPI_COMM_WORLD);
	MPI_Finalize();

	return 0;
}