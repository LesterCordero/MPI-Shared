#include <mpi.h> 
#include <iostream>
#include <random>
#include <chrono>
using namespace std;

//#define DEBUG
int main(int argc, char* argv[]) {

	// Inicializacion de MPI
	int process_ID;                  
	int process_num;                 
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &process_ID);
	MPI_Comm_size(MPI_COMM_WORLD, &process_num);

	// Modo de uso
	if (argc < 2) {
		cout << "Error: debe pasar un entero multiplo de 2 que indique la precision de aproximacion para Pi." << endl;
		cin.ignore();
		exit(0);
	}

	// Parametros y datos iniciales
	int precision;                   // Precision de calculo	
	double resultado;                // Resultado
	MPI_Status mpi_status;           // Estado de error/salida
	precision = strtol(argv[1], NULL, 10);

	// Semilla al azar para la funcion
	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	default_random_engine generator(seed);
	uniform_real_distribution<float> distribution(-1.0, 1.0);

	// Cronometro
	MPI_Barrier(MPI_COMM_WORLD);

	double local_start = MPI_Wtime();

	// Codigo paralelo
	if (process_ID == 0) {
		cout << "[MPI] EL ambiente MPI ha iniciado correctamente." << endl;
		cout << "[MPI] Numero de procesos paralelos: " << process_num << endl;
		cout << "[INF] Precision para el calculo: " << precision << endl;
	}

	int aciertos = 0;
	int aciertos_total = 0;

	double sector = precision / process_num;
	
	for (int i = sector*process_ID; i < (sector*process_ID) + sector; i++) {
		double x = distribution(generator);
		double y = distribution(generator);
		double d = sqrt(x*x + y*y);
		if (d <= 1) {
			aciertos++;
		}
	}
	
	MPI_Reduce(&aciertos, &aciertos_total, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
	resultado = (4 * (double) aciertos_total) / (double)precision;

	// Seccion de debugging
	#  ifdef DEBUG 
	if (mid == 0)
		cin.ignore();
	MPI_Barrier(MPI_COMM_WORLD);
	#  endif

	double total_elapsed;
	double local_elapsed = MPI_Wtime() - local_start;

	MPI_Reduce(&local_elapsed, &total_elapsed, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

	// Termina MPI
	if (process_ID == 0) {
		cout << "[INF] Calculo aproximado de Pi: " << resultado << endl;
		cout << "[INF] Tiempo transcurrido: " << total_elapsed << endl;
		cout << "[MPI] EL ambiente MPI ha terminado correctamente." << endl;



		cin.ignore();
	}
	MPI_Barrier(MPI_COMM_WORLD); // para sincronizar la finalización de los procesos
	MPI_Finalize();

	return 0;
}  