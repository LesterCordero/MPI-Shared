#include <mpi.h> 
#include <iostream>
#include <random>
#include <chrono>
#include <cmath>

using namespace std;

bool enRango(int n, int a, int b) {
	return (a <= n && n <= b);
}

int main(int argc, char* argv[]) {

	// Inicializacion básica de MPI
	int process_ID;                  
	int process_num;                 
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &process_ID);
	MPI_Comm_size(MPI_COMM_WORLD, &process_num);

	// Modo de uso obligatorio
	if (argc < (5)) {
		cout << "Error: debe pasar: cantidad de rangos, valor min, valor max y numero de randoms." << endl;
		cin.ignore();
		exit(0);
	}

	// Datos inciales del enunciado
	MPI_Status mpi_status;
	int rangos = strtol(argv[1], NULL, 10);
	int valorMin = strtol(argv[2], NULL, 10);
	int valorMax = strtol(argv[3], NULL, 10); 
	int numeros = strtol(argv[4], NULL, 10);

	// Semilla al azar para la funcion
	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	mt19937 generator(seed);
	uniform_int_distribution<int> distribution(valorMin, valorMax);

	// Cronometro sincronizado
	MPI_Barrier(MPI_COMM_WORLD);
	double local_start = MPI_Wtime();

	// Notificacion de parámetros iniciales
	if (process_ID == 0) {
		cout << "[MPI] EL ambiente MPI ha iniciado correctamente." << endl;
		cout << "[MPI] Numero de procesos paralelos: " << process_num << endl;
		cout << "[INF] Numero de rangos: " << rangos << endl;
		cout << "[INF] Valor minimo para los numeros: " << valorMin << endl;
		cout << "[INF] Valor maximo para los numeros: " << valorMax << endl;
		cout << "[INF] Cantidad de numeros random: " << numeros << endl;
	}

	// Cuantos numeros debe calcular cada proceso
	int sub = numeros / process_num;
	int rdiv = (abs(valorMax - valorMin)) / rangos;

	// Haga random la secuencia aun mas
	srand(time(NULL));

	// Cree los contadores
	int* local_counter = new int[rangos]();

	// Generacion de numeros al azar y agrupacion en paralelo
	for (int i = sub*process_ID; i < (sub*process_ID) + sub; ++i) {
		int actual = distribution(generator);
		
		for (int j = 0; j < rangos; j++) {
			if (enRango(actual, j*rdiv, j*rdiv + rdiv)) {
				local_counter[j]++;
				break;
			}
		}
		
	}

	// Envio mis contadores a los demas procesos
	if (process_ID != 0) {

		MPI_Send(local_counter, rangos, MPI_INT, 0, 0, MPI_COMM_WORLD);

	}else {

		int* total_counter = new int[rangos]();
		int* msg_counter = new int[rangos]();

		// Copie los datos de mi mismo al contador maestro
		for (int k = 0; k < rangos; k++) {
			total_counter[k] += local_counter[k];
		}

		// Reciba todos los mensajes de cada numero calculado en subgrupos
		for (int i = 1; i < process_num; i++) {
			MPI_Recv(msg_counter, rangos, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			
			for (int k = 0; k < rangos; k++) {
				total_counter[k] += msg_counter[k];
			}
		}

		for (int k = 0; k < rangos; k++) {
			printf("%5i  - %5i  >>  ", rdiv*k, rdiv*k + rdiv);
			for (int k2 = 0; k2 < (int)(numeros/total_counter[k]); k2++) {
				printf("X");
			}
			printf("\n");
		}

		delete[] msg_counter;
		delete[] total_counter;
		
	}

	// Elimina la memoria
	delete[] local_counter;

	// Cronometro final
	double total_elapsed;
	double local_elapsed = MPI_Wtime() - local_start;

	MPI_Reduce(&local_elapsed, &total_elapsed, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

	// Termina MPI
	if (process_ID == 0) {
		cout << "[INF] Tiempo transcurrido: " << total_elapsed << endl;
		cout << "[MPI] EL ambiente MPI ha terminado correctamente." << endl;

		cin.ignore();
	}

	MPI_Barrier(MPI_COMM_WORLD);
	MPI_Finalize();

	return 0;
}  