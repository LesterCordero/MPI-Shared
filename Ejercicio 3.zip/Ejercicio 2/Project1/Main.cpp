#include <mpi.h> 
#include <iostream>
#include <sstream>
#include <string>
#include <random>
#include <chrono>
#include <cmath>

using namespace std;

bool esPrimo(int n){
	// Para cada i, basta que tenga un divisor "adicional"
	// para que no sea un numero primo
	int i = 2;
	while ((i*i) <= n){
		if (n % i == 0){
			return false;
		}
		i++;
	}
	// Eficiencia de algoritmo: sqrt(n)
	return true;
}

int main(int argc, char* argv[]) {

	// Inicializacion básica de MPI
	int process_ID;                  
	int process_num;                 
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &process_ID);
	MPI_Comm_size(MPI_COMM_WORLD, &process_num);

	// Modo de uso obligatorio
	if (argc < (2)) {
		cout << "Error: debe pasar: cantidad de numeros." << endl;
		cin.ignore();
		exit(0);
	}

	// Datos inciales del enunciado
	MPI_Status mpi_status;
	int n = strtol(argv[1], NULL, 10);

	// Notificacion de parámetros iniciales
	if (process_ID == 0) {
		cout << "[MPI] EL ambiente MPI ha iniciado correctamente." << endl;
		cout << "[MPI] Numero de procesos paralelos: " << process_num << endl;
		cout << "[INF] Numero de iteraciones (n): " << n << endl;
		cout << "[INF] Calculando, por favor espere..." << endl;
	}

	// Cronometro sincronizado
	MPI_Barrier(MPI_COMM_WORLD);
	double local_start = MPI_Wtime();

	// Cada hilo tiene su propia lista de primos generada (no necesita estar compartido, asi que puede ser vector)
	vector<int> primos;
	for (int i = 2; i < (n - 1); i++) {
		if (esPrimo(i)) {
			primos.push_back(i);
		}
	}

	// String grande de cada hilo (contendra el mensaje que se enviara de un solo)
	stringstream msg_prepare;

	// Divida la tarea entre los hilos diferentes
	// Para cada numero desde 5 hasta N, encuentre su sumatoria de primos
	int seccion = n / process_num;
	for (int i = 5 + seccion*process_ID ; i < 5 + (seccion * process_ID) + seccion && i <= n; i++) {

		if (i % 2 == 0) {
			// Si el numero es par, sabemos que puede ser representado por 2 números primos
			// Seamos greedy para el caso de dos numeros
			
			for (int a = 0; a < primos.size() && a < i; a++) {
				for (int b = a-1; b < primos.size() && b < i; b++) {
					int ax = primos.at(a);
					int bx = primos.at(b);

					if ((ax+bx) == i) {
						// Si es el Proceso 0, solo imprimilado, sino metalo en buffer para despues enviarlo
						if (process_ID == 0) {
							msg_prepare << "[ID" << process_ID << "] " << i << " = " << ax << " + " << bx << endl;
						}else{
							msg_prepare << "[ID" << process_ID << "] " << i << " = " << ax << " + " << bx;
							if ((i + 1) != 5 + (seccion * process_ID) + seccion) {
								msg_prepare << endl;
							}
						}
						goto breakNested;
					}
				}
			}
		}else {
			// Si el numero es impar, sabemos que puede ser representado por 3 números primos
			for (int a = 0; a < primos.size() && a < i; a++) {
				for (int b = a-1; b < primos.size() && b < i; b++) {
					for (int c = b-1; c < primos.size() && c < i; c++) {
						int ax = primos.at(a);
						int bx = primos.at(b);
						int cx = primos.at(c);
						if ((ax + bx + cx) == i) {
							// Si es el Proceso 0, solo imprimilado, sino metalo en buffer para despues enviarlo
							if (process_ID == 0) {
								msg_prepare << "[ID" << process_ID << "] " << i << " = " << ax << " + " << bx << " + " << cx << endl;
							}else {
								msg_prepare << "[ID" << process_ID << "] " << i << " = " << ax << " + " << bx << " + " << cx;
								// Si NO es la ultima linea, haga append
								if ((i + 1) != 5 + (seccion * process_ID) + seccion) {
									msg_prepare << endl;
								}
							}
							goto breakNested;
						}
					}
				}
			}
		}
		breakNested: {}
	}



	// Ahora que ya tiene todos los numeros, mande sus calculos e hileras DE UN SOLO en un unico mensaje
	// El proceso 0 no se va enviar nada a si mismo, ya que ya lo tiene
	string msg = msg_prepare.str();
	if (process_ID != 0) {
		const char* msg_formatoChar = msg.c_str();
		MPI_Send(msg_formatoChar, strlen(msg_formatoChar)+1, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
	}else {
		// Imprima mi parte
		cout << msg;
		// Soy el proceso master, reciba todos los mensajes
		char* destino = new char[32*seccion];
		for (int q = 1; q < process_num; q++) {
			MPI_Recv(destino, 32*seccion, MPI_CHAR, q, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			cout << destino;
			if (q + 1 != process_num) {
				cout << endl;
			}
		}
		delete destino;

	}

	// Cronometro final
	double total_elapsed;
	double local_elapsed = MPI_Wtime() - local_start;

	MPI_Reduce(&local_elapsed, &total_elapsed, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

	// Termina MPI
	if (process_ID == 0) {
		cout << "[INF] Tiempo transcurrido: " << total_elapsed << endl;
		cout << "[MPI] EL ambiente MPI ha terminado correctamente." << endl;

		cin.ignore();
	}

	MPI_Barrier(MPI_COMM_WORLD);
	MPI_Finalize();

	return 0;
}  